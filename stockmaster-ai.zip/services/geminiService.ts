
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const getInventoryInsights = async (products: Product[]) => {
  const model = ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this inventory data and provide 3 key business insights or recommendations: ${JSON.stringify(products)}`,
    config: {
      systemInstruction: "You are a senior supply chain analyst. Provide concise, actionable insights based on stock levels, thresholds, and categories. Format the response as a bulleted list of 3 points.",
    }
  });

  const response = await model;
  return response.text;
};

export const suggestReorder = async (products: Product[]) => {
  const lowStock = products.filter(p => p.quantity <= p.minThreshold);
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a suggested reorder list for these items: ${JSON.stringify(lowStock)}. Include estimated cost if items are restocked to 2x their threshold.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            suggestedQuantity: { type: Type.NUMBER },
            estimatedCost: { type: Type.NUMBER },
            priority: { type: Type.STRING, description: "High, Medium, or Low" }
          },
          required: ["name", "suggestedQuantity", "estimatedCost", "priority"]
        }
      }
    }
  });

  return JSON.parse(response.text || '[]');
};

export const chatWithInventory = async (query: string, products: Product[]) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Question about inventory: ${query}. Inventory data: ${JSON.stringify(products)}`,
    config: {
      systemInstruction: "You are a helpful inventory assistant. Use the provided data to answer questions. If the data doesn't contain the answer, say so politely."
    }
  });

  return response.text;
};

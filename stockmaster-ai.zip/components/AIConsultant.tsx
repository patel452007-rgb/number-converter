
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { getInventoryInsights, suggestReorder, chatWithInventory } from '../services/geminiService';
import { Sparkles, Loader2, Send, ChevronRight, AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  products: Product[];
}

const AIConsultant: React.FC<Props> = ({ products }) => {
  const [insights, setInsights] = useState<string>('');
  const [reorderList, setReorderList] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  const fetchAIInsights = async () => {
    setLoading(true);
    try {
      const [insightData, reorderData] = await Promise.all([
        getInventoryInsights(products),
        suggestReorder(products)
      ]);
      setInsights(insightData || 'No insights available.');
      setReorderList(reorderData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAIInsights();
  }, [products.length]);

  const handleChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatLoading(true);
    try {
      const res = await chatWithInventory(chatInput, products);
      setChatResponse(res || 'I couldn\'t process that request.');
    } catch (err) {
      setChatResponse('Error connecting to AI assistant.');
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Smart Insights Panel */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold flex items-center gap-2 text-indigo-700">
              <Sparkles className="w-5 h-5" />
              Strategic Insights
            </h3>
            <button 
              onClick={fetchAIInsights}
              disabled={loading}
              className="p-2 text-slate-400 hover:text-indigo-600 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          
          {loading ? (
            <div className="flex flex-col items-center py-10 space-y-3">
              <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
              <p className="text-slate-400 text-sm italic">Gemini is analyzing your supply chain...</p>
            </div>
          ) : (
            <div className="prose prose-slate max-w-none">
              <div className="whitespace-pre-wrap text-slate-700 leading-relaxed">
                {insights || "No strategic data yet."}
              </div>
            </div>
          )}
        </div>

        {/* Reorder Suggestions */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-amber-700">
            <AlertTriangle className="w-5 h-5" />
            AI Reorder Recommendations
          </h3>
          <div className="space-y-3">
            {reorderList.length > 0 ? (
              reorderList.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="flex flex-col">
                    <span className="font-semibold text-slate-800">{item.name}</span>
                    <span className={`text-xs font-bold uppercase tracking-wide ${item.priority === 'High' ? 'text-rose-600' : 'text-amber-600'}`}>
                      {item.priority} Priority
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-slate-900">Restock {item.suggestedQuantity} units</p>
                    <p className="text-xs text-slate-500">Est. Cost: ${item.estimatedCost.toLocaleString()}</p>
                  </div>
                  <button className="ml-4 p-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors">
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              ))
            ) : (
              <div className="text-center py-6 bg-emerald-50 rounded-lg border border-emerald-100 text-emerald-700">
                <p className="text-sm font-medium">All items are sufficiently stocked.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="bg-slate-900 rounded-xl shadow-xl flex flex-col h-[600px]">
        <div className="p-4 border-b border-slate-800 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <h3 className="text-white font-semibold">Inventory Assistant</h3>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="bg-slate-800 text-slate-300 p-3 rounded-lg rounded-tl-none text-sm self-start max-w-[85%]">
            Hello! Ask me anything about your stock levels, trends, or specific items.
          </div>
          
          {chatResponse && (
            <div className="bg-indigo-600 text-white p-3 rounded-lg rounded-tl-none text-sm self-start max-w-[85%]">
              {chatResponse}
            </div>
          )}
          
          {chatLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs italic p-2">
              <Loader2 className="w-3 h-3 animate-spin" /> Assistant is thinking...
            </div>
          )}
        </div>

        <form onSubmit={handleChat} className="p-4 border-t border-slate-800 flex gap-2">
          <input 
            type="text" 
            placeholder="How much total value do we have?"
            className="flex-1 bg-slate-800 border-none rounded-lg px-4 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
          />
          <button 
            type="submit"
            disabled={chatLoading}
            className="bg-indigo-500 text-white p-2 rounded-lg hover:bg-indigo-400 transition-colors disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AIConsultant;

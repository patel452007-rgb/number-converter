
import React from 'react';
import { Product, DashboardStats } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie
} from 'recharts';
import { AlertCircle, Package, TrendingUp, DollarSign } from 'lucide-react';

interface Props {
  products: Product[];
}

const Dashboard: React.FC<Props> = ({ products }) => {
  const stats: DashboardStats = {
    totalItems: products.reduce((acc, p) => acc + p.quantity, 0),
    totalValue: products.reduce((acc, p) => acc + (p.price * p.quantity), 0),
    lowStockCount: products.filter(p => p.quantity > 0 && p.quantity <= p.minThreshold).length,
    outOfStockCount: products.filter(p => p.quantity === 0).length,
  };

  const chartData = products.slice(0, 10).map(p => ({
    name: p.name,
    quantity: p.quantity,
    status: p.quantity === 0 ? 'Out' : p.quantity <= p.minThreshold ? 'Low' : 'OK'
  }));

  const categoryData = Array.from(new Set(products.map(p => p.category))).map(cat => ({
    name: cat,
    value: products.filter(p => p.category === cat).length
  }));

  const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316'];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          label="Total Inventory Count" 
          value={stats.totalItems.toLocaleString()} 
          icon={<Package className="text-indigo-600" />}
          color="bg-indigo-50"
        />
        <StatCard 
          label="Total Inventory Value" 
          value={`$${stats.totalValue.toLocaleString()}`} 
          icon={<DollarSign className="text-emerald-600" />}
          color="bg-emerald-50"
        />
        <StatCard 
          label="Low Stock Items" 
          value={stats.lowStockCount} 
          icon={<AlertCircle className="text-amber-600" />}
          color="bg-amber-50"
          alert={stats.lowStockCount > 0}
        />
        <StatCard 
          label="Out of Stock" 
          value={stats.outOfStockCount} 
          icon={<AlertCircle className="text-rose-600" />}
          color="bg-rose-50"
          alert={stats.outOfStockCount > 0}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory Levels Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Inventory Levels (Top 10)</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" fontSize={12} tick={{ fill: '#64748b' }} />
                <YAxis fontSize={12} tick={{ fill: '#64748b' }} />
                <Tooltip />
                <Bar dataKey="quantity" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.status === 'Out' ? '#f43f5e' : entry.status === 'Low' ? '#f59e0b' : '#6366f1'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Category Distribution</h3>
          <div className="h-[300px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon, color, alert = false }: { label: string, value: string | number, icon: React.ReactNode, color: string, alert?: boolean }) => (
  <div className={`p-6 rounded-xl border border-slate-200 shadow-sm flex items-start space-x-4 bg-white`}>
    <div className={`p-3 rounded-lg ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className={`text-2xl font-bold mt-1 ${alert ? 'text-rose-600' : 'text-slate-900'}`}>{value}</p>
    </div>
  </div>
);

export default Dashboard;

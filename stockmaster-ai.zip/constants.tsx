
import { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'MacBook Pro M3',
    sku: 'MBP-M3-001',
    category: 'Electronics',
    quantity: 12,
    minThreshold: 5,
    price: 2499,
    lastUpdated: new Date().toISOString(),
    description: 'Latest Apple silicon laptop'
  },
  {
    id: '2',
    name: 'Ergonomic Office Chair',
    sku: 'CHR-ERG-99',
    category: 'Furniture',
    quantity: 3,
    minThreshold: 10,
    price: 350,
    lastUpdated: new Date().toISOString(),
    description: 'High-back mesh chair with lumbar support'
  },
  {
    id: '3',
    name: 'Wireless Mouse',
    sku: 'MS-WL-101',
    category: 'Electronics',
    quantity: 45,
    minThreshold: 15,
    price: 49.99,
    lastUpdated: new Date().toISOString(),
    description: 'Optical mouse with Bluetooth connectivity'
  },
  {
    id: '4',
    name: 'Standing Desk',
    sku: 'DSK-STD-02',
    category: 'Furniture',
    quantity: 0,
    minThreshold: 2,
    price: 599,
    lastUpdated: new Date().toISOString(),
    description: 'Motorized height-adjustable desk'
  }
];

export const CATEGORIES = [
  'Electronics',
  'Furniture',
  'Stationery',
  'Software',
  'Kitchenware',
  'Other'
];

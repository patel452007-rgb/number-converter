
import React, { useState, useEffect } from 'react';
import { Product, AppTab } from './types';
import { INITIAL_PRODUCTS } from './constants';
import Dashboard from './components/Dashboard';
import InventoryTable from './components/InventoryTable';
import AIConsultant from './components/AIConsultant';
import ProductModal from './components/ProductModal';
import { LayoutDashboard, Package, Sparkles, LogOut, Bell, Settings, Search, Menu } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | undefined>();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleSaveProduct = (data: Partial<Product>) => {
    if (editingProduct) {
      setProducts(products.map(p => p.id === editingProduct.id ? { ...p, ...data, lastUpdated: new Date().toISOString() } : p));
    } else {
      const newProduct: Product = {
        ...data as any,
        id: Math.random().toString(36).substr(2, 9),
        lastUpdated: new Date().toISOString()
      };
      setProducts([...products, newProduct]);
    }
    setIsModalOpen(false);
    setEditingProduct(undefined);
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      setProducts(products.filter(p => p.id !== id));
    }
  };

  const lowStockItems = products.filter(p => p.quantity <= p.minThreshold);

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 bg-white border-r border-slate-200 transition-all duration-300 ease-in-out ${sidebarOpen ? 'w-64' : 'w-20'}`}>
        <div className="h-full flex flex-col">
          <div className="p-6 flex items-center gap-3 border-b border-slate-100">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shrink-0 shadow-lg shadow-indigo-200">
              <Package className="w-5 h-5" />
            </div>
            {sidebarOpen && <span className="font-bold text-xl tracking-tight text-slate-800">StockMaster</span>}
          </div>

          <nav className="flex-1 py-6 px-4 space-y-1">
            <NavItem 
              icon={<LayoutDashboard className="w-5 h-5" />} 
              label="Dashboard" 
              active={activeTab === AppTab.DASHBOARD} 
              onClick={() => setActiveTab(AppTab.DASHBOARD)} 
              collapsed={!sidebarOpen}
            />
            <NavItem 
              icon={<Package className="w-5 h-5" />} 
              label="Inventory" 
              active={activeTab === AppTab.INVENTORY} 
              onClick={() => setActiveTab(AppTab.INVENTORY)} 
              collapsed={!sidebarOpen}
            />
            <NavItem 
              icon={<Sparkles className="w-5 h-5" />} 
              label="AI Assistant" 
              active={activeTab === AppTab.AI_INSIGHTS} 
              onClick={() => setActiveTab(AppTab.AI_INSIGHTS)} 
              collapsed={!sidebarOpen}
            />
          </nav>

          <div className="p-4 border-t border-slate-100 space-y-1">
            <NavItem 
              icon={<Settings className="w-5 h-5" />} 
              label="Settings" 
              active={activeTab === AppTab.SETTINGS} 
              onClick={() => {}} 
              collapsed={!sidebarOpen}
            />
            <button className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-rose-600 transition-colors w-full rounded-xl hover:bg-rose-50">
              <LogOut className="w-5 h-5" />
              {sidebarOpen && <span className="font-medium">Logout</span>}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold text-slate-800 capitalize">{activeTab.replace('_', ' ')}</h2>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Global Search..."
                className="bg-slate-100 border-none rounded-full pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 transition-all w-64"
              />
            </div>
            
            <div className="relative">
              <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors relative">
                <Bell className="w-5 h-5" />
                {lowStockItems.length > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white"></span>
                )}
              </button>
            </div>

            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-xs">
                JD
              </div>
              <div className="hidden lg:block">
                <p className="text-sm font-semibold text-slate-800">John Doe</p>
                <p className="text-xs text-slate-500">Warehouse Admin</p>
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-8">
          {activeTab === AppTab.DASHBOARD && <Dashboard products={products} />}
          
          {activeTab === AppTab.INVENTORY && (
            <InventoryTable 
              products={products} 
              onAdd={() => { setEditingProduct(undefined); setIsModalOpen(true); }}
              onEdit={(p) => { setEditingProduct(p); setIsModalOpen(true); }}
              onDelete={handleDeleteProduct}
            />
          )}

          {activeTab === AppTab.AI_INSIGHTS && <AIConsultant products={products} />}

          {activeTab === AppTab.SETTINGS && (
            <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
              <Settings className="w-16 h-16 mb-4 opacity-20" />
              <p className="text-lg">Settings coming soon.</p>
            </div>
          )}
        </div>
      </main>

      <ProductModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        product={editingProduct}
        onSave={handleSaveProduct}
      />
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick, collapsed }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void, collapsed: boolean }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 w-full rounded-xl transition-all ${active ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'}`}
  >
    <span className={active ? 'text-indigo-600' : 'text-slate-400'}>{icon}</span>
    {!collapsed && <span>{label}</span>}
    {!collapsed && active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-indigo-600 shadow-lg shadow-indigo-300"></div>}
  </button>
);

export default App;
